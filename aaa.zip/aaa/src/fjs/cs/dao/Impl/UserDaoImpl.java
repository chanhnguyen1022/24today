package fjs.cs.dao.Impl;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import fjs.cs.dao.UserDao;
import fjs.cs.model.MSTUSER;


public class UserDaoImpl extends HibernateDaoSupport implements UserDao {
	private static SessionFactory factory;

	@Override
	public boolean authenticate(String UserId, String Password) {
	 Session session = factory.openSession();
	 Transaction tx = null;
	
	    tx = session.beginTransaction();
	    Query query=session.createQuery("SELECT COUNT(*) AS CNT FROM MSTUSER WHERE USERID= :USERID AND PASSWORD= :PASSWORD AND DELETE_YMD IS NULL");
		query.setString("USERID",UserId);
		query.setString("PASSWORD",Password);
		MSTUSER mstuser=(MSTUSER) query.uniqueResult();
		tx.commit();
		if(mstuser!=null){
			return true;
		
}else {
		return false;
	

}
	}
}