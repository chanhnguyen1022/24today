package fjs.cs.dao.Impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import fjs.cs.action.form.CustomerForm;
import fjs.cs.action.form.EditForm;
import fjs.cs.action.form.SearchForm;
import fjs.cs.dao.CustomerDao;

public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao{
	private static SessionFactory factory;
	private final int LIMIT = 15;
	// Ket qua cua viec edit hay add customer.
	private boolean check = false;
	@Override
	
	public List<CustomerForm> getAllcustomers(int index, SearchForm searchForm) {
		List<CustomerForm> customers = new ArrayList<CustomerForm>();
		
			StringBuffer sql = new StringBuffer();
			int start = index * LIMIT;
			int end = start + LIMIT;
			sql.append("SELECT * FROM ( SELECT *, ROW_NUMBER() OVER (ORDER BY CUSTOMER_ID ) as row FROM MSTCUSTOMER WHERE DELETE_YMD IS NULL ");
			
			if (searchForm != null) {
				changeQuery(sql, searchForm);
			}
			sql.append(" ) a WHERE row > "+ start + " and row <= " + end);
			
		try {
			
			
			
		}catch (Exception e) {
			// TODO: handle exception
		}


		return customers;

	}

	private void changeQuery(StringBuffer query, SearchForm searchForm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int countCustomers() throws SQLException {
	List list=getHibernateTemplate().find("SELECT Count(CUSTOMER_ID) FROM MSTCUSTOMER WHERE DELETE_YMD IS NULL ");
	Integer count=(Integer) list.get(0);
		return count.intValue();
	}

	@Override
	public void deleted(int i) throws SQLException {
			Session session = factory.openSession();
			Transaction tx = null;
		
		    tx = session.beginTransaction();
		    Query query=session.createQuery("UPDATE MSTCUSTOMER SET DELETE_YMD=:DELETE_YMD WHERE CUSTOMER_ID= :CUSTOMER_ID");
			query.setDate("DELETE_YMD",new java.sql.Date(new Date().getTime()));
			query.setInteger("CUSTOMER_ID",i);
			query.executeUpdate();
			tx.commit();
			
	}

	@Override
	public boolean EditCustomer(EditForm ef) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Transaction tx = null;
	
	    tx = session.beginTransaction();
	    Query query=session.createQuery("UPDATE MSTCUSTOMER SET" + " CUSTOMER_NAME=:CUSTOMER_NAME, SEX= :SEX, BIRTHDAY=:BIRTHDAY, "
				+ "ADDRESS=:ADDRESS, EMAIL=:EMAIL, INSERT_YMD=:INSERT_YMD, INSERT_PSN_CD=:INSERT_PSN_CD," + " UPDATE_PSN_CD=:UPDATE_PSN_CD WHERE CUSTOMER_ID=:CUSTOMER_ID");
		query.setString("CUSTOMER_NAME", ef.getCustomerName());
		query.setString("SEX",ef.getSex());
		query.setString("BIRTHDAY", ef.getBirthDay());
		query.setString("ADDRESS", ef.getAddress());
		query.setString("EMAIL", ef.getEmail());
		query.setDate("INSERT_YMD", new java.sql.Date(new Date().getTime()));
		query.setInteger("INSERT_PSN_CD", ef.getInsertPSN());
		query.setInteger("UPDATE_PSN_CD", ef.getUpdatePSN());
		query.setInteger("CUSTOMER_ID",ef.getUserid());
		tx.commit();
		int i=query.executeUpdate();
		if(i>0){
			check=true;
		
		}
		return check;
	}
	@Override
	public boolean addCustomer(EditForm ac) throws SQLException {
		Session session = factory.openSession();
		Transaction tx = null;
	
	    tx = session.beginTransaction();
	    Query query=session.createQuery("INSERT INTO MSTCUSTOMER (CUSTOMER_NAME=:CUSTOMER_NAME,SEX=SEX:,BIRTHDAY=:BIRTHDAY,ADDRESS=:ADDRESS,EMAIL=:EMAIL,INSERT_YMD=:INSERT_YMD,INSERT_PSN_CD=:INSERT_PSN_CD,UPDATE_PSN_CD=:UPDATE_PSN_CD)");
	    query.setString("CUSTOMER_NAME", ac.getCustomerName());
		query.setString("SEX",ac.getSex());
		query.setString("BIRTHDAY", ac.getBirthDay());
		query.setString("ADDRESS", ac.getAddress());
		query.setString("EMAIL", ac.getEmail());
		query.setDate("INSERT_YMD", new java.sql.Date(new Date().getTime()));
		query.setInteger("INSERT_PSN_CD", ac.getInsertPSN());
		query.setInteger("UPDATE_PSN_CD", ac.getUpdatePSN());
		int i=query.executeUpdate();
		tx.commit();
		if(i>0){
			check=true;
		
		}
		return check;
	}
	@Override
	public EditForm getEditForm(int userid) throws SQLException {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
		Transaction tx = null;
	
	    tx = session.beginTransaction();
	    Query query=session.createQuery("SELECT*FROM MSTCUSTOMER WHERE CUSTOMER_ID= :CUSTOMER_ID");
	    query.setInteger("CUSTOMER_NAME",userid);
	    
		return null;
	}

	@Override
	public int getPSNCDbyUsername(String customername) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<CustomerForm> searchCustomers(SearchForm searchForm) {
		// TODO Auto-generated method stub
		return null;
	}

}
