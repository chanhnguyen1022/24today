package fjs.cs.model;

import java.util.Date;

public class MSTUSER implements java.io.Serializable{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private int psn_cd;
		private String userid;
		private String password;
		private String username;
		private Date delete_ymd;
		private Date insert_yms;
		private int insert_psn_cd;
		private Date update_ymd;
		private int update_psn_cd;
		public int getPsn_cd() {
			return psn_cd;
		}
		public void setPsn_cd(int psn_cd) {
			this.psn_cd = psn_cd;
		}
		public String getUserid() {
			return userid;
		}
		public void setUserid(String userid) {
			this.userid = userid;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public Date getDelete_ymd() {
			return delete_ymd;
		}
		public void setDelete_ymd(Date delete_ymd) {
			this.delete_ymd = delete_ymd;
		}
		public Date getInsert_yms() {
			return insert_yms;
		}
		public void setInsert_yms(Date insert_yms) {
			this.insert_yms = insert_yms;
		}
		public int getInsert_psn_cd() {
			return insert_psn_cd;
		}
		public void setInsert_psn_cd(int insert_psn_cd) {
			this.insert_psn_cd = insert_psn_cd;
		}
		public Date getUpdate_ymd() {
			return update_ymd;
		}
		public void setUpdate_ymd(Date update_ymd) {
			this.update_ymd = update_ymd;
		}
		public int getUpdate_psn_cd() {
			return update_psn_cd;
		}
		public void setUpdate_psn_cd(int update_psn_cd) {
			this.update_psn_cd = update_psn_cd;
		}

		
}
