/**
 * @(#)SearchAction.java 01-00 2017/08/16.
 * Copyright(C) FUJINET CO., LTD.
 *
 * Version 1.00.
 */
package fjs.cs.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.*;
import org.springframework.web.struts.ActionSupport;

import fjs.cs.action.form.SearchForm;
import fjs.cs.action.form.CustomerForm;
import fjs.cs.bo.CustomerBo;



/**
 * SearchAction
 *
 * @author chanh-nm 2017/08/21
 * @version 1.00
 */
public class SearchAction extends ActionSupport {

	/**
	 * ActionMapping mapping ActionForm form HttpServletRequest request
	 * HttpServletResponse response
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SearchForm searchForm = (SearchForm) form;
		
		List<CustomerForm> allSize;
		List<CustomerForm> listSub;
		HttpSession session = request.getSession();
		String message = (String)session.getAttribute("message");
		
		SearchForm formSession = (SearchForm) session.getAttribute("searchForm");
		if (message != null && searchForm != null) {
			searchForm = formSession;
			session.removeAttribute("message");
		}
		CustomerBo dao=(CustomerBo) getWebApplicationContext().getBean("customerBo");
		allSize = dao.searchCustomers(searchForm);
		listSub = dao.getAllcustomers(0, searchForm);
		request.setAttribute("list", listSub);
		System.out.println( listSub.size());
		request.setAttribute("start", 0);
		request.setAttribute("all", allSize.size());
		System.out.println( allSize.size());
		// lﾆｰu l蘯｡i d盻ｯ li盻㎡ search vﾃ� session
		session.setAttribute("searchForm", searchForm);
		// Di chuyen den man hinh Search
		return mapping.findForward("result");
	}
}
		