/**
 * @(#)UserLoginAction.java 01-00 2017/08/16.
 * Copyright(C) FUJINET CO., LTD.
 *
 * Version 1.00.
 */
package fjs.cs.action.form;


import org.apache.struts.action.ActionForm;

/**
 * UserLoginAction
 *
 * @author chanh-nm 2017/08/21
 * @version 1.00
 */
public class UserLoginForm extends ActionForm {

	private static final long serialVersionUID = 1L;
	//Bien userid luu gia tri userid nhap vao cua user.
	private String userid;
	//Bien password luu gia tri password nhap vao cua user.
	private String password;
	
	
	public UserLoginForm() {
	}


	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}