package fjs.cs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.struts.ActionSupport;

import fjs.cs.action.form.UserLoginForm;
import fjs.cs.bo.UserBo;

public class UserLoginAction extends ActionSupport{
	public ActionForward execute(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request, HttpServletResponse response)throws Exception{
		
		UserLoginForm loginForm = (UserLoginForm) form;

		String username = loginForm.getUserid();

		String password = loginForm.getPassword();
				

		boolean checkLoginFlg = false;

		UserBo dao = (UserBo) getWebApplicationContext().getBean("userBo");
		checkLoginFlg = dao.authenticate(username,password);
		

		if (checkLoginFlg) {
		
			HttpSession se = request.getSession();
			se.setAttribute("username", username);
			return mapping.findForward("success");
		}else {
			

			String error="���[�U�[ID�܂��̓p�X���[�h���s���ł��B";
			request.setAttribute("lblErrorMessage",error);
		}	
		return mapping.findForward("failure");
		
	}

}
