/**
 * @(#)addAction.java 01-00 2017/08/16.
 * Copyright(C) FUJINET CO., LTD.
 *
 * Version 1.00.
 */
package fjs.cs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.struts.ActionSupport;


import fjs.cs.action.form.EditForm;
import fjs.cs.action.form.SearchForm;
import fjs.cs.bo.CustomerBo;

/**
 * addAction
 * 
 * @author chanh-nm 2017/08/21
 * @version 1.00
 */
public class addAction extends ActionSupport {

	/**
	 * ActionMapping mapping ActionForm form HttpServletRequest request
	 * HttpServletResponse response
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		CustomerBo customerBo=(CustomerBo) getWebApplicationContext().getBean("customerBo");
		
		EditForm editForm = (EditForm) form;

		HttpSession session= request.getSession();
		
		String name = (String) session.getAttribute("username");
	
		int PSN_CD = customerBo.getPSNCDbyUsername(name);
		
		editForm.setInsertPSN(PSN_CD);

		customerBo.addCustomer(editForm);
		session.setAttribute("message", "true");
		SearchForm searchForm = (SearchForm) session.getAttribute("searchForm");
		
		if(searchForm == null){
			return mapping.findForward("result2");
		}
		return mapping.findForward("result1");
	}
}