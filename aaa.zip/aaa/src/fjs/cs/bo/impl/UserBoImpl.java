package fjs.cs.bo.impl;

import fjs.cs.dao.UserDao;

public class UserBoImpl implements UserDao{

	@Override
	public boolean authenticate(String UserId, String Password) {
		// TODO Auto-generated method stub
		return false;
	}

}
