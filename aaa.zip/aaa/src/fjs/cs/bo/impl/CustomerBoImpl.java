package fjs.cs.bo.impl;

import java.sql.SQLException;
import java.util.List;

import fjs.cs.action.form.CustomerForm;
import fjs.cs.action.form.EditForm;
import fjs.cs.action.form.SearchForm;
import fjs.cs.bo.CustomerBo;
import fjs.cs.dao.CustomerDao;

public class CustomerBoImpl implements CustomerBo {
	
	CustomerDao customerDao;

	@Override
	public List<CustomerForm> getAllcustomers(int index, SearchForm searchForm) {
		// TODO Auto-generated method stub
		return customerDao.getAllcustomers(index, searchForm);
	}

	@Override
	public int countCustomers() throws SQLException {
		// TODO Auto-generated method stub
		return customerDao.countCustomers();
	}

	@Override
	public void deleted(int i) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean EditCustomer(EditForm ef) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean addCustomer(EditForm ac) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public EditForm getEditForm(int userid) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getPSNCDbyUsername(String customername) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<CustomerForm> searchCustomers(SearchForm searchForm) {
		// TODO Auto-generated method stub
		return null;
	}

}
