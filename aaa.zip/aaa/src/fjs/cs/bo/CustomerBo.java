package fjs.cs.bo;

import java.sql.SQLException;
import java.util.List;

import fjs.cs.action.form.CustomerForm;
import fjs.cs.action.form.EditForm;
import fjs.cs.action.form.SearchForm;


public interface CustomerBo {
	public List<CustomerForm> getAllcustomers(int index, SearchForm searchForm); 
	public int countCustomers() throws SQLException ;
	public void deleted(int i) throws SQLException ;
	public boolean EditCustomer(EditForm ef) ;
	public boolean addCustomer(EditForm ac) throws SQLException;
	public EditForm getEditForm(int userid) throws SQLException;
	public int getPSNCDbyUsername(String customername) throws SQLException ;
	public List<CustomerForm> searchCustomers(SearchForm searchForm);
}
