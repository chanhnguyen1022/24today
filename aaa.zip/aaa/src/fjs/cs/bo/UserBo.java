package fjs.cs.bo;

public interface UserBo {
	public boolean authenticate(String UserId, String Password);
}
